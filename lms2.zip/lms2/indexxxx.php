<?php
include('includes/header.php');
include('includes/sidebar.php');
?>


<!-- Main Content Panel -->
        <div class="content-wrapper">
            <div class="row">
                <div class="col-sm-12">
                    <!-- What ever creating, create here -->
                    <h3>Dashboard</h3>
                </div>
            </div>
        </div>
<!-- Main Content ends -->

<?php

include('includes/footer.php');

?>