<?php
// include('config.php');
// header('Access-Control-Allow-Origin:*');
// header('Content-Type:application/json');
// header('Access-Control-Allow-Methods:Post');
// header('Access-Control-Allow-Headers:Content-Type,Access-Control-Allow-Headers,Authorization,X-Request-With');


// $data = json_decode(file_get_contents("php://input"));

// $query = "INSERT INTO  topics(topicName) values ()"